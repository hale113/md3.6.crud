create definer = root@localhost view giasp as
select `p`.`id` AS `id`, `p`.`price` AS `price`
from `demo2006`.`product` `p`
group by `p`.`price`
order by `p`.`price` desc
limit 3;

