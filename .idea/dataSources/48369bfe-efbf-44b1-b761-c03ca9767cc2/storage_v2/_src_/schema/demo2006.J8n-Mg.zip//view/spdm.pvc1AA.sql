create definer = root@localhost view spdm as
select `demo2006`.`orderdetail`.`orderId` AS `orderId`, count(`demo2006`.`orderdetail`.`productId`) AS `sldm`
from `demo2006`.`orderdetail`
group by `demo2006`.`orderdetail`.`orderId`;

