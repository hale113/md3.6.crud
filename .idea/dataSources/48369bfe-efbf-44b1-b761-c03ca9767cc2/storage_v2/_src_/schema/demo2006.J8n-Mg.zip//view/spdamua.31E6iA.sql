create definer = root@localhost view spdamua as
select `demo2006`.`order`.`id` AS `id`, `c`.`name` AS `name`, sum(`o`.`quantity`) AS `sl`
from (((`demo2006`.`order` join `demo2006`.`orderdetail` `o`
        on ((`demo2006`.`order`.`id` = `o`.`orderId`))) join `demo2006`.`product` `p`
       on ((`p`.`id` = `o`.`productId`))) join `demo2006`.`customer` `c`
      on ((`c`.`id` = `demo2006`.`order`.`customerId`)))
group by `demo2006`.`order`.`id`
order by `sl` desc;

