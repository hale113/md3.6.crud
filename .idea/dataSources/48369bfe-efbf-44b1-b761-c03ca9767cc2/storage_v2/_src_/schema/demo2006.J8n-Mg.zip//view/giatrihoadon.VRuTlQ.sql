create definer = root@localhost view giatrihoadon as
select `demo2006`.`order`.`id` AS `id`, `c`.`name` AS `name`, sum((`p`.`price` * `o`.`quantity`)) AS `total`
from (((`demo2006`.`order` join `demo2006`.`customer` `c`
        on ((`demo2006`.`order`.`customerId` = `c`.`id`))) join `demo2006`.`orderdetail` `o`
       on ((`demo2006`.`order`.`id` = `o`.`orderId`))) join `demo2006`.`product` `p` on ((`p`.`id` = `o`.`productId`)))
where (year(`demo2006`.`order`.`time`) = '2006')
group by `demo2006`.`order`.`id`;

